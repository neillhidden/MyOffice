const path=require('node:path');
const os=require('node:os');
if(process.platform!=='win32'){console.error('Este atalho de fontes destina-se ao Windows.');process.exit(1);}
process.env.MYOFFICE_DATA_DIR=path.join(process.env.APPDATA||path.join(os.homedir(),'AppData','Roaming'),'MyOffice','dados');
process.env.MYOFFICE_PORT='4742';
require(path.join(__dirname,'app','backend.cjs'));
